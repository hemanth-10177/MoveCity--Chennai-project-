# MoveCity Chennai — Student Demo

## Run the project
1. Extract the ZIP file.
2. Open the extracted `movecity-chennai-fixed` folder in VS Code.
3. Open `index.html` in Chrome, or use the VS Code Live Server extension.
4. Keep an internet connection enabled for the interactive OpenStreetMap tiles, place search and OSRM road routing.

## Included features
- Chennai-region map using Leaflet and OpenStreetMap tiles, with map bounds limited to Chennai and nearby surroundings.
- From/To place search with common Chennai landmarks and bounded place lookup.
- Find & Compare Routes draws a blue route line with start and destination markers and zooms to the selected route.
- Six travel options in this order: Bike, Auto, Car, Electric Train, Metro and Bus.
- Electric Train and Metro ticket-options dialog with passenger minus/plus controls and a demo booking confirmation.
- Responsive layout and demo sign-in dialog.

## Important limitations
- Route distance/time uses public OSRM road routing. If that service is unavailable, the map displays a clearly labelled approximate straight line instead of claiming it is a road route.
- Fares and transit times are illustrative estimates, not official operator fares or live schedules.
- The train/metro button saves a demo selection only. It does not issue an official ticket or accept payment.
- Sign-in is demo-only. Real authentication, ride booking, live transit schedules and payments require backend services and authorized operator APIs.
- Public OpenStreetMap, Nominatim and OSRM services require internet and have usage policies/rate limits.
